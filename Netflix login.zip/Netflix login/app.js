document.addEventListener('DOMContentLoaded', ()=>{
  const form = document.getElementById('authForm');
  const email = document.getElementById('email');
  const pwField = document.getElementById('passwordField');
  const password = document.getElementById('password');
  const btn = document.getElementById('continueBtn');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const msg = document.getElementById('authMsg');
    // first step: show password
    if (pwField.style.display === 'none'){
      const em = email.value && email.value.trim();
      if(!em){ msg.textContent = 'Please enter an email.'; return; }
      pwField.style.display = 'block';
      password.focus();
      btn.textContent = 'Sign In';
      msg.textContent = '';
      return;
    }

    // second step: validate password and sign in or send to create-profile
    const payload = { email: email.value && email.value.trim(), password: password.value };
    if(!payload.password || payload.password.length < 4){ msg.textContent = 'Please enter a password (min 4 chars).'; return; }

    // check localStorage for existing profiles linked to this email
    const raw = localStorage.getItem('profiles') || '[]';
    let profiles = [];
    try{ profiles = JSON.parse(raw); } catch(e){ profiles = []; }
    const match = profiles.find(p => p.email && p.email.toLowerCase() === (payload.email||'').toLowerCase());
    if(match){
      // redirect to watch with the matched profile
      const dest = 'watch.html?email=' + encodeURIComponent(payload.email) + '&profile=' + encodeURIComponent(match.name);
      window.location.href = dest;
      return;
    }

    // no profile exists: go to create-profile
    const dest = 'create-profile.html?email=' + encodeURIComponent(payload.email || '');
    window.location.href = dest;
  });
});
