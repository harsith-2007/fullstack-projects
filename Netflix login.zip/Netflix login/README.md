# Netflix-style Login — Frontend

Files created:

- index.html
- styles.css
- app.js

How to preview:

1. Open `index.html` in your browser (double-click or use Live Server).
2. Enter an email and click `Continue` to reveal the password field, then `Sign In` to submit.

New behavior:

- After signing in the prototype redirects to `watch.html` where you can 'Start Watching'.
- There's also a bottom "Log in" link on the sign-in card that goes directly to `watch.html`.
 - After signing in the prototype now redirects to `create-profile.html` to create a profile.
 - After creating a profile you'll be redirected to `watch.html` with the selected profile and email in the querystring.
 - The bottom "Log in" link on the sign-in card goes to `create-profile.html`.
 - The header logo now reads `NETFLIX`.
 - The `watch.html` page is now a richer homepage with a hero, navigation, and multiple horizontally-scrollable movie rows built from sample data.
 - Movie cards are placeholders generated client-side; clicking a card shows a placeholder alert.
 - Navigation links now work and point to these pages: `watch.html`, `shows.html`, `movies.html`, `new.html`, and `mylist.html`.
 - `movies.html`, `shows.html`, and `new.html` include many poster images (loaded from picsum.photos) and let you add items to `My List` by clicking a card.
 - `mylist.html` reads saved items from `localStorage` and displays them.

Notes:

- This is a static, client-side prototype. Replace the alert in `app.js` with real API calls to integrate authentication.
- For a local dev server, you can use `npx serve` or the VS Code Live Server extension.
