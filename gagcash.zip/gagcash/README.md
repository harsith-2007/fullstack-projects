GagCash — Demo static site

This folder contains a simple static demo of a second-hand gadget selling landing site named "GagCash".

Files:

- index.html — homepage with search, categories, brand grid, and interactive brand model selector
- styles.css — site styles
- login.html — demo login page
- register.html — demo register page
- search.html — search results and price checker page
- contact.html — contact page with locations and contact info
- sell.html — form to add phones for sale
- listings.html — display all phones listed for sale by users

Features:

1. **Brand Model Navigation** — Click any brand tile (Apple, Samsung, OnePlus, etc.) to see available models in a popup
2. **Price Checker** — Input your phone's brand, model, and condition on the search page to get an estimated quote
3. **Contact Locations** — Three offices in Coimbatore, Chennai, and Bangalore with email and phone numbers
4. **Sell Your Phone** — Add your phone to the listings with brand, model, condition, price, and contact details
5. **View Listings** — See all phones listed for sale by other users with their contact information
6. **Search & Navigation** — Search for models, browse by category or brand

Demo login credentials (client-side only):

- Email: demo@gagcash.test
- Password: Password123

How to use:

1. Open `index.html` in your browser to view the homepage.
2. Click on any brand tile to see the models popup.
3. Click "Sell Your Phone" button to list a phone for sale.
4. Go to "Listings" (from the Sell page) to see all phones available for sale.
5. Try the search page's price checker to get estimates.
6. Click "Contact" in the header to see office locations.

**Note:** Products are stored locally in your browser using localStorage. They persist within the same browser session but will be cleared if browser data is deleted.

Next steps I can help with:

- Convert to a React app with routing and state management
- Add a backend (Node/Express + SQLite) to persist listings and user data
- Add image uploads for product listings
- Implement user authentication and seller dashboards

Tell me which next step you want and I will proceed.
