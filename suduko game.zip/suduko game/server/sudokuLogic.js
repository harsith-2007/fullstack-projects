// Sudoku game logic functions

/**
 * Check if a number is valid at a given position
 */
function isValid(board, row, col, num) {
    // Check row
    for (let j = 0; j < 9; j++) {
        if (board[row][j] === num) return false;
    }

    // Check column
    for (let i = 0; i < 9; i++) {
        if (board[i][col] === num) return false;
    }

    // Check 3x3 box
    const boxRow = Math.floor(row / 3) * 3;
    const boxCol = Math.floor(col / 3) * 3;
    for (let i = boxRow; i < boxRow + 3; i++) {
        for (let j = boxCol; j < boxCol + 3; j++) {
            if (board[i][j] === num) return false;
        }
    }

    return true;
}

/**
 * Solve Sudoku using backtracking algorithm
 */
function solveSudoku(board) {
    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            if (board[i][j] === 0) {
                for (let num = 1; num <= 9; num++) {
                    if (isValid(board, i, j, num)) {
                        board[i][j] = num;
                        if (solveSudoku(board)) {
                            return true;
                        }
                        board[i][j] = 0;
                    }
                }
                return false;
            }
        }
    }
    return true;
}

/**
 * Check if the given solution is valid
 */
function isValidSolution(board) {
    // Check if all cells are filled
    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            if (board[i][j] === 0) return false;
        }
    }

    // Check rows
    for (let i = 0; i < 9; i++) {
        const seen = new Set();
        for (let j = 0; j < 9; j++) {
            const num = board[i][j];
            if (seen.has(num)) return false;
            seen.add(num);
        }
    }

    // Check columns
    for (let j = 0; j < 9; j++) {
        const seen = new Set();
        for (let i = 0; i < 9; i++) {
            const num = board[i][j];
            if (seen.has(num)) return false;
            seen.add(num);
        }
    }

    // Check 3x3 boxes
    for (let boxRow = 0; boxRow < 9; boxRow += 3) {
        for (let boxCol = 0; boxCol < 9; boxCol += 3) {
            const seen = new Set();
            for (let i = boxRow; i < boxRow + 3; i++) {
                for (let j = boxCol; j < boxCol + 3; j++) {
                    const num = board[i][j];
                    if (seen.has(num)) return false;
                    seen.add(num);
                }
            }
        }
    }

    return true;
}

/**
 * Generate a complete solved Sudoku board
 */
function generateCompleteSudoku() {
    const board = Array(9).fill(null).map(() => Array(9).fill(0));

    function fillBoard() {
        for (let i = 0; i < 9; i++) {
            for (let j = 0; j < 9; j++) {
                if (board[i][j] === 0) {
                    const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9];
                    // Shuffle numbers
                    for (let k = numbers.length - 1; k > 0; k--) {
                        const r = Math.floor(Math.random() * (k + 1));
                        [numbers[k], numbers[r]] = [numbers[r], numbers[k]];
                    }

                    for (const num of numbers) {
                        if (isValid(board, i, j, num)) {
                            board[i][j] = num;
                            if (fillBoard()) {
                                return true;
                            }
                            board[i][j] = 0;
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }

    fillBoard();
    return board;
}

/**
 * Generate a Sudoku puzzle with a given difficulty
 */
function generatePuzzle(difficulty = 'medium') {
    // Complete solution
    const solution = generateCompleteSudoku();

    // Create puzzle by removing cells
    const puzzle = solution.map(row => [...row]);
    let cellsToRemove;

    switch (difficulty) {
        case 'easy':
            cellsToRemove = 30;
            break;
        case 'hard':
            cellsToRemove = 50;
            break;
        case 'medium':
        default:
            cellsToRemove = 40;
    }

    let removed = 0;
    while (removed < cellsToRemove) {
        const row = Math.floor(Math.random() * 9);
        const col = Math.floor(Math.random() * 9);

        if (puzzle[row][col] !== 0) {
            puzzle[row][col] = 0;
            removed++;
        }
    }

    return {
        board: puzzle,
        solution: solution,
        difficulty: difficulty
    };
}

/**
 * Get a hint for the current board
 */
function getHint(board) {
    const solution = generateCompleteSudoku();

    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            if (board[i][j] === 0) {
                return {
                    hint: {
                        row: i,
                        col: j,
                        value: solution[i][j]
                    }
                };
            }
        }
    }

    return null;
}

module.exports = {
    isValid,
    solveSudoku,
    isValidSolution,
    generateCompleteSudoku,
    generatePuzzle,
    getHint
};
