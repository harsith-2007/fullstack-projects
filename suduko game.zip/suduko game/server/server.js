const express = require('express');
const cors = require('cors');
const path = require('path');
const sudokuLogic = require('./sudokuLogic');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Routes

/**
 * Generate a new Sudoku puzzle
 * Returns: { board: 9x9 array, solution: 9x9 array, difficulty: string }
 */
app.get('/api/generate', (req, res) => {
    try {
        const difficulty = req.query.difficulty || 'medium';
        const puzzle = sudokuLogic.generatePuzzle(difficulty);
        res.json(puzzle);
    } catch (error) {
        res.status(500).json({ error: 'Error generating puzzle' });
    }
});

/**
 * Solve a given Sudoku puzzle
 * Body: { board: 9x9 array }
 * Returns: { solution: 9x9 array }
 */
app.post('/api/solve', (req, res) => {
    try {
        const { board } = req.body;
        if (!board) {
            return res.status(400).json({ error: 'Board is required' });
        }

        const boardCopy = board.map(row => [...row]);
        const solved = sudokuLogic.solveSudoku(boardCopy);
        
        if (solved) {
            res.json({ solution: boardCopy });
        } else {
            res.status(400).json({ error: 'Could not solve the puzzle' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Error solving puzzle' });
    }
});

/**
 * Check if the solution is valid
 * Body: { board: 9x9 array }
 * Returns: { isValid: boolean }
 */
app.post('/api/check', (req, res) => {
    try {
        const { board } = req.body;
        if (!board) {
            return res.status(400).json({ error: 'Board is required' });
        }

        const isValid = sudokuLogic.isValidSolution(board);
        res.json({ isValid });
    } catch (error) {
        res.status(500).json({ error: 'Error checking solution' });
    }
});

/**
 * Get hints for the current board
 * Body: { board: 9x9 array }
 * Returns: { hint: { row, col, value } }
 */
app.post('/api/hint', (req, res) => {
    try {
        const { board } = req.body;
        if (!board) {
            return res.status(400).json({ error: 'Board is required' });
        }

        const hint = sudokuLogic.getHint(board);
        if (hint) {
            res.json(hint);
        } else {
            res.status(400).json({ error: 'No hints available' });
        }
    } catch (error) {
        res.status(500).json({ error: 'Error getting hint' });
    }
});

// Serve index.html for root path
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`Sudoku Game server running at http://localhost:${PORT}`);
    console.log(`Press Ctrl+C to stop the server`);
});
