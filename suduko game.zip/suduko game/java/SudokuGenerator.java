/**
 * SudokuGenerator.java
 * Generates valid Sudoku puzzles with various difficulty levels
 */

public class SudokuGenerator {
    private int[][] board;
    private static final int SIZE = 9;
    private static final int EMPTY = 0;

    /**
     * Constructor
     */
    public SudokuGenerator() {
        board = new int[SIZE][SIZE];
    }

    /**
     * Generate a complete, solved Sudoku board
     */
    public void generateSolution() {
        fillBoard();
    }

    /**
     * Fill the board using backtracking
     */
    private boolean fillBoard() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == EMPTY) {
                    // Get random numbers 1-9 shuffled
                    java.util.List<Integer> numbers = new java.util.ArrayList<>();
                    for (int k = 1; k <= SIZE; k++) {
                        numbers.add(k);
                    }
                    java.util.Collections.shuffle(numbers);

                    for (int num : numbers) {
                        if (isValid(i, j, num)) {
                            board[i][j] = num;
                            if (fillBoard()) {
                                return true;
                            }
                            board[i][j] = EMPTY;
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Check if a number is valid at a position
     */
    private boolean isValid(int row, int col, int num) {
        // Check row
        for (int j = 0; j < SIZE; j++) {
            if (board[row][j] == num) return false;
        }

        // Check column
        for (int i = 0; i < SIZE; i++) {
            if (board[i][col] == num) return false;
        }

        // Check 3x3 box
        int boxRow = (row / 3) * 3;
        int boxCol = (col / 3) * 3;
        for (int i = boxRow; i < boxRow + 3; i++) {
            for (int j = boxCol; j < boxCol + 3; j++) {
                if (board[i][j] == num) return false;
            }
        }

        return true;
    }

    /**
     * Generate a puzzle with given difficulty
     * Difficulty: 1-5 (1=easy, 5=hard)
     */
    public int[][] generatePuzzle(int difficulty) {
        generateSolution();
        int[][] puzzle = new int[SIZE][SIZE];
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                puzzle[i][j] = board[i][j];
            }
        }

        int cellsToRemove = difficulty * 10; // Easy: 10, Hard: 50
        int removed = 0;

        while (removed < cellsToRemove) {
            int row = (int) (Math.random() * SIZE);
            int col = (int) (Math.random() * SIZE);

            if (puzzle[row][col] != EMPTY) {
                puzzle[row][col] = EMPTY;
                removed++;
            }
        }

        return puzzle;
    }

    /**
     * Get the solved board
     */
    public int[][] getSolution() {
        return board;
    }

    /**
     * Print the board
     */
    public void printBoard(int[][] board) {
        for (int i = 0; i < SIZE; i++) {
            if (i % 3 == 0 && i != 0) {
                System.out.println("-----------");
            }
            for (int j = 0; j < SIZE; j++) {
                if (j % 3 == 0 && j != 0) {
                    System.out.print("|");
                }
                System.out.print(board[i][j]);
            }
            System.out.println();
        }
    }

    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        SudokuGenerator generator = new SudokuGenerator();

        System.out.println("Generating Easy Puzzle:");
        int[][] easyPuzzle = generator.generatePuzzle(1);
        generator.printBoard(easyPuzzle);

        System.out.println("\nGenerated Solution:");
        generator.printBoard(generator.getSolution());
    }
}
