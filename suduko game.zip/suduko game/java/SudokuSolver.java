/**
 * SudokuSolver.java
 * Advanced Sudoku solver with multiple algorithms
 * Can be compiled and used as a utility for the Node.js backend
 */

public class SudokuSolver {
    private int[][] board;
    private static final int SIZE = 9;
    private static final int EMPTY = 0;

    /**
     * Constructor
     */
    public SudokuSolver(int[][] board) {
        this.board = board;
    }

    /**
     * Solve the Sudoku puzzle using backtracking
     */
    public boolean solve() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == EMPTY) {
                    for (int num = 1; num <= SIZE; num++) {
                        if (isValid(i, j, num)) {
                            board[i][j] = num;
                            if (solve()) {
                                return true;
                            }
                            board[i][j] = EMPTY;
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Check if a number is valid at a given position
     */
    private boolean isValid(int row, int col, int num) {
        // Check row
        for (int j = 0; j < SIZE; j++) {
            if (board[row][j] == num) {
                return false;
            }
        }

        // Check column
        for (int i = 0; i < SIZE; i++) {
            if (board[i][col] == num) {
                return false;
            }
        }

        // Check 3x3 box
        int boxRow = (row / 3) * 3;
        int boxCol = (col / 3) * 3;
        for (int i = boxRow; i < boxRow + 3; i++) {
            for (int j = boxCol; j < boxCol + 3; j++) {
                if (board[i][j] == num) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Get all candidates for a given cell
     */
    public java.util.Set<Integer> getCandidates(int row, int col) {
        java.util.Set<Integer> candidates = new java.util.HashSet<>();
        if (board[row][col] != EMPTY) {
            return candidates;
        }

        for (int num = 1; num <= SIZE; num++) {
            if (isValid(row, col, num)) {
                candidates.add(num);
            }
        }
        return candidates;
    }

    /**
     * Validate the current board state
     */
    public boolean isValid() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                int num = board[i][j];
                board[i][j] = EMPTY;
                if (!isValid(i, j, num)) {
                    board[i][j] = num;
                    return false;
                }
                board[i][j] = num;
            }
        }
        return true;
    }

    /**
     * Check if the board is completely and validly solved
     */
    public boolean isSolved() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                if (board[i][j] == EMPTY) {
                    return false;
                }
            }
        }
        return isValid();
    }

    /**
     * Get the current board
     */
    public int[][] getBoard() {
        return board;
    }

    /**
     * Print the board for debugging
     */
    public void printBoard() {
        for (int i = 0; i < SIZE; i++) {
            if (i % 3 == 0 && i != 0) {
                System.out.println("-----------");
            }
            for (int j = 0; j < SIZE; j++) {
                if (j % 3 == 0 && j != 0) {
                    System.out.print("|");
                }
                System.out.print(board[i][j]);
            }
            System.out.println();
        }
    }

    /**
     * Main method for testing
     */
    public static void main(String[] args) {
        // Example puzzle
        int[][] puzzle = {
            {5, 3, 0, 0, 7, 0, 0, 0, 0},
            {6, 0, 0, 1, 9, 5, 0, 0, 0},
            {0, 9, 8, 0, 0, 0, 0, 6, 0},
            {8, 0, 0, 0, 6, 0, 0, 0, 3},
            {4, 0, 0, 8, 0, 3, 0, 0, 1},
            {7, 0, 0, 0, 2, 0, 0, 0, 6},
            {0, 6, 0, 0, 0, 0, 2, 8, 0},
            {0, 0, 0, 4, 1, 9, 0, 0, 5},
            {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };

        SudokuSolver solver = new SudokuSolver(puzzle);
        System.out.println("Puzzle:");
        solver.printBoard();

        if (solver.solve()) {
            System.out.println("\nSolution:");
            solver.printBoard();
        } else {
            System.out.println("No solution found!");
        }
    }
}
