class SudokuGame {
    constructor() {
        this.board = [];
        this.original = [];
        this.solution = [];
        this.difficulty = 'medium';
        this.selectedCell = null;
        this.startTime = null;
        this.timerInterval = null;
        this.init();
    }

    async init() {
        this.setupEventListeners();
        await this.newGame();
    }

    setupEventListeners() {
        document.getElementById('newGameBtn').addEventListener('click', () => this.newGame());
        document.getElementById('solveBtn').addEventListener('click', () => this.solve());
        document.getElementById('resetBtn').addEventListener('click', () => this.reset());
        document.getElementById('checkBtn').addEventListener('click', () => this.checkSolution());
    }

    async newGame() {
        try {
            const response = await fetch('/api/generate');
            const data = await response.json();
            
            this.board = JSON.parse(JSON.stringify(data.board));
            this.original = JSON.parse(JSON.stringify(data.board));
            this.solution = JSON.parse(JSON.stringify(data.solution));
            this.difficulty = data.difficulty;
            
            document.getElementById('difficulty').textContent = this.difficulty.charAt(0).toUpperCase() + this.difficulty.slice(1);
            this.startTime = Date.now();
            this.startTimer();
            this.render();
            this.clearMessage();
        } catch (error) {
            console.error('Error generating new game:', error);
            this.showMessage('Error generating game', 'error');
        }
    }

    async solve() {
        try {
            const response = await fetch('/api/solve', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ board: this.board })
            });
            const data = await response.json();
            this.board = data.solution;
            this.render();
            this.showMessage('Puzzle solved!', 'success');
            clearInterval(this.timerInterval);
        } catch (error) {
            console.error('Error solving puzzle:', error);
            this.showMessage('Error solving puzzle', 'error');
        }
    }

    reset() {
        this.board = JSON.parse(JSON.stringify(this.original));
        this.render();
        this.startTime = Date.now();
        this.clearMessage();
    }

    async checkSolution() {
        try {
            const response = await fetch('/api/check', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ board: this.board })
            });
            const data = await response.json();
            
            if (data.isValid) {
                this.showMessage('Congratulations! You solved the puzzle! 🎉', 'success');
                clearInterval(this.timerInterval);
            } else {
                this.showMessage('Some numbers are incorrect. Keep trying!', 'error');
            }
        } catch (error) {
            console.error('Error checking solution:', error);
            this.showMessage('Error checking solution', 'error');
        }
    }

    render() {
        const gameBoard = document.getElementById('gameBoard');
        gameBoard.innerHTML = '';

        for (let i = 0; i < 9; i++) {
            for (let j = 0; j < 9; j++) {
                const cell = document.createElement('div');
                cell.className = 'cell';
                cell.dataset.row = i;
                cell.dataset.col = j;

                if (this.original[i][j] !== 0) {
                    cell.classList.add('given');
                    cell.textContent = this.board[i][j];
                } else {
                    const input = document.createElement('input');
                    input.type = 'text';
                    input.maxLength = '1';
                    input.value = this.board[i][j] !== 0 ? this.board[i][j] : '';
                    input.addEventListener('input', (e) => this.handleInput(e, i, j));
                    input.addEventListener('focus', (e) => this.selectCell(e, i, j));
                    cell.appendChild(input);
                }

                cell.addEventListener('click', () => this.selectCell(cell, i, j));
                gameBoard.appendChild(cell);
            }
        }
    }

    handleInput(e, row, col) {
        const value = e.target.value;

        if (value === '') {
            this.board[row][col] = 0;
        } else if (/^[1-9]$/.test(value)) {
            this.board[row][col] = parseInt(value);
        } else {
            e.target.value = this.board[row][col] !== 0 ? this.board[row][col] : '';
            return;
        }

        this.highlightRelated(row, col);
    }

    selectCell(e, row, col) {
        if (this.original[row][col] !== 0) return;

        // Remove previous selection
        document.querySelectorAll('.cell.selected').forEach(cell => {
            cell.classList.remove('selected');
        });

        const cell = document.querySelector(`[data-row="${row}"][data-col="${col}"]`);
        cell.classList.add('selected');
        this.selectedCell = { row, col };
    }

    highlightRelated(row, col) {
        document.querySelectorAll('.cell.highlighted').forEach(cell => {
            cell.classList.remove('highlighted');
        });

        // Highlight row
        for (let j = 0; j < 9; j++) {
            if (j !== col) {
                const cell = document.querySelector(`[data-row="${row}"][data-col="${j}"]`);
                cell.classList.add('highlighted');
            }
        }

        // Highlight column
        for (let i = 0; i < 9; i++) {
            if (i !== row) {
                const cell = document.querySelector(`[data-row="${i}"][data-col="${col}"]`);
                cell.classList.add('highlighted');
            }
        }

        // Highlight 3x3 box
        const boxRow = Math.floor(row / 3) * 3;
        const boxCol = Math.floor(col / 3) * 3;
        for (let i = boxRow; i < boxRow + 3; i++) {
            for (let j = boxCol; j < boxCol + 3; j++) {
                if (i !== row || j !== col) {
                    const cell = document.querySelector(`[data-row="${i}"][data-col="${j}"]`);
                    cell.classList.add('highlighted');
                }
            }
        }
    }

    startTimer() {
        clearInterval(this.timerInterval);
        this.timerInterval = setInterval(() => {
            const elapsed = Math.floor((Date.now() - this.startTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            document.getElementById('timer').textContent = 
                `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        }, 1000);
    }

    showMessage(text, type) {
        const messageDiv = document.getElementById('message');
        messageDiv.textContent = text;
        messageDiv.className = `message ${type}`;
    }

    clearMessage() {
        const messageDiv = document.getElementById('message');
        messageDiv.textContent = '';
        messageDiv.className = 'message';
    }
}

// Initialize game when page loads
window.addEventListener('DOMContentLoaded', () => {
    new SudokuGame();
});
